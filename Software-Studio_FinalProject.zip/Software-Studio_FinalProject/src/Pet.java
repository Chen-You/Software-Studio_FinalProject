import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


import javax.imageio.ImageIO;
public class Pet {
	private int CurrentX, CurrentY;
	public File f1 = new File("ConnectButton.png");
}
