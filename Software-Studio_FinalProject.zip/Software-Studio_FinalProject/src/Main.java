import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args)throws IOException{
		GameStage gs = new GameStage();
		/*Mywindow w1 = new Mywindow();
		w1.doSomeWork();*/
		/*Thread s = new Thread(w1);
		s.start();*/
	}
	
}
